# AmeerFit Android Project

Native Android wrapper around the AmeerFit Professional V2 prototype.

Application ID: com.ameerfit.app
Version: 1.0 (versionCode 1)

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. For Google Play, use Build > Generate Signed Bundle / APK and choose Android App Bundle (AAB).

The project intentionally has no ad SDK yet. Add AdMob only after the app has been tested and a suitable publisher/developer account is available.
